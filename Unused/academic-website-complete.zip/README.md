# Academic Personal Website for Junke Zhao

A clean, professional academic website designed for PhD applications in HCI, Tangible Interaction, and Digital Fabrication fields.

## Features

- **Responsive Design**: Works perfectly on desktop, tablet, and mobile devices
- **Clean Academic Layout**: Inspired by top academic websites with focus on research and publications
- **Smooth Animations**: Subtle fade-in effects and smooth scrolling
- **SEO Friendly**: Proper semantic HTML structure
- **Easy to Customize**: Well-organized code with clear sections

## File Structure

```
academic-website/
├── index.html          # Main HTML file
├── styles.css          # All styling
├── script.js           # Interactive features
├── README.md           # This file
└── assets/             # Create this folder for your images
    ├── profile.jpg
    ├── research-transformable-furniture.jpg
    ├── research-architecture-tech.jpg
    └── research-ubiquitous.jpg
```

## Setup Instructions

### 1. Add Your Images

Create an `assets` folder and add the following images:

- **profile.jpg**: Your professional headshot (250x250px recommended)
- **research-transformable-furniture.jpg**: Main research project image
- **research-architecture-tech.jpg**: Architecture research image
- **research-ubiquitous.jpg**: Ubiquitous computing research image

Update the image paths in `index.html` to point to your images:
```html
<img src="assets/profile.jpg" alt="Junke Zhao">
```

### 2. Customize Personal Information

In `index.html`, update:

- **Name and Affiliation**: Lines 35-40
- **Email**: Replace `junke.zhao@utdallas.edu` with your actual email
- **Social Media Links**: Lines 55-67
  - Google Scholar ID
  - LinkedIn profile
  - GitHub username
  - Twitter handle

### 3. Update Research Content

**Research Projects** (Lines 200-280):
- Add details about your transformable furniture research
- Include images and descriptions
- Update project status and dates

**Publications** (Lines 290-340):
- Add your actual publications
- Include co-authors, venues, and links
- Add awards or special recognitions

**Experience** (Lines 350-420):
- Update timeline with your actual positions
- Add research assistant details
- Include relevant experiences

### 4. Add Your CV

Place your CV PDF in the root directory and name it `cv.pdf`, or update all references to `cv.pdf` in the HTML to match your filename.

## Customization Guide

### Changing Colors

Edit the CSS variables in `styles.css` (lines 9-17):

```css
:root {
    --primary-color: #2c3e50;      /* Main headings */
    --secondary-color: #3498db;     /* Accents and links */
    --accent-color: #e74c3c;        /* Highlights */
    --text-color: #333;             /* Body text */
    /* ... other colors ... */
}
```

### Adding Sections

To add a new section:

1. Add navigation link in the navbar:
```html
<li><a href="#newsection" class="nav-link">New Section</a></li>
```

2. Add section content:
```html
<section id="newsection" class="newsection">
    <div class="container">
        <h2 class="section-title">New Section</h2>
        <!-- Your content here -->
    </div>
</section>
```

3. Add styling in `styles.css`

### Modifying Layout

The website uses CSS Grid for layouts. Main breakpoints:
- Desktop: > 968px
- Tablet: 640px - 968px
- Mobile: < 640px

Adjust grid columns in the responsive section (lines 650+ in styles.css).

## Deployment Options

### Option 1: GitHub Pages (Free)

1. Create a GitHub repository
2. Upload all files
3. Go to Settings > Pages
4. Select main branch
5. Your site will be at `https://yourusername.github.io/repository-name`

### Option 2: Netlify (Free)

1. Create account at netlify.com
2. Drag and drop your folder
3. Get instant deployment
4. Custom domain available

### Option 3: Custom Domain

1. Purchase domain (e.g., junkezhao.com)
2. Use any hosting service (GitHub Pages, Netlify, Vercel)
3. Point domain to your hosting

## Best Practices for Academic Websites

1. **Keep It Updated**: Regularly update publications and research
2. **Professional Photos**: Use high-quality, professional images
3. **Clear Navigation**: Make it easy to find your CV and contact info
4. **Mobile Friendly**: Many people will view on phones
5. **Fast Loading**: Optimize images (use compressed JPGs)
6. **Accessible**: Use proper alt text for images
7. **Contact Info**: Make it very easy to reach you

## Content Recommendations

### What to Include

- ✅ Clear research statement
- ✅ Current position and affiliation
- ✅ Publications (with links if available)
- ✅ CV download link
- ✅ Contact information
- ✅ Professional photo
- ✅ Research interests
- ✅ Notable projects

### What to Avoid

- ❌ Outdated information
- ❌ Too much personal information
- ❌ Overly complex navigation
- ❌ Slow-loading large images
- ❌ Broken links
- ❌ Unprofessional content

## SEO Tips

1. Update the `<title>` tag with your name and field
2. Add meta description:
```html
<meta name="description" content="Junke Zhao - HCI Researcher specializing in tangible interaction and digital fabrication">
```
3. Use descriptive alt text for images
4. Keep URLs simple and clean
5. Submit sitemap to Google Search Console

## Troubleshooting

### Images Not Showing
- Check file paths are correct
- Ensure images are in the assets folder
- Verify image file names match HTML references

### Styling Issues
- Clear browser cache (Ctrl+Shift+R or Cmd+Shift+R)
- Check CSS file is linked correctly
- Verify no typos in class names

### Mobile Menu Not Working
- Ensure script.js is loaded
- Check browser console for errors
- Test on different mobile devices

## Maintenance Schedule

- **Weekly**: Check for broken links
- **Monthly**: Update news/publications
- **Quarterly**: Review all content for accuracy
- **Annually**: Major redesign if needed

## Additional Resources

- [Google Fonts](https://fonts.google.com/) - Add custom fonts
- [Font Awesome](https://fontawesome.com/) - Icons library
- [TinyPNG](https://tinypng.com/) - Image compression
- [Can I Use](https://caniuse.com/) - Browser compatibility

## Support

For questions about customization:
1. Check this README first
2. Review comments in HTML/CSS files
3. Search online for specific CSS/HTML questions
4. Consider hiring a web developer for major changes

## License

This template is provided as-is for personal academic use. Feel free to customize and use for your academic website.

---

**Created for**: Junke Zhao
**Last Updated**: November 2024
**Version**: 1.0

Good luck with your PhD applications! 🎓
