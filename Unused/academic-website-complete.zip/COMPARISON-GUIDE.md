# Website Style Comparison Guide

## Two Complete Website Options for Junke Zhao

You now have **TWO complete academic website designs** to choose from, each with different aesthetics and features.

---

## Option 1: Professional Academic Style
**Files**: `index.html`, `styles.css`, `script.js`

### Design Characteristics
- **Aesthetic**: Clean, bright, traditional academic
- **Color Scheme**: Light backgrounds with blue accents
- **Layout**: Grid-based with clear sections
- **Navigation**: Top navbar
- **Vibe**: Professional, approachable, comprehensive

### Best For
✅ PhD applications to traditional programs  
✅ Showcasing comprehensive research portfolio  
✅ Maximum information density  
✅ Professional academic audiences  
✅ Clear, straightforward presentation

### Key Features
- Multiple detailed sections
- Publication-focused layout
- Timeline-based experience display
- Comprehensive skills showcase
- Research interests prominently displayed
- Status banner for PhD applications

### Pros
- Traditional academic credibility
- Information-rich
- Easy to scan
- Familiar layout
- Works great for print/PDF

### Cons
- More conventional design
- No dark mode
- Less "modern tech" feel

---

## Option 2: Modern Dark Style (Xia Su Inspired)
**Files**: `index-xiasu-style.html`, `style.css`, `project-style.css`, `script-main.js`

### Design Characteristics
- **Aesthetic**: Modern, dark, tech-forward
- **Color Scheme**: Dark backgrounds with vibrant accents
- **Layout**: Sidebar + content area
- **Navigation**: Fixed sidebar with profile
- **Vibe**: Contemporary, innovative, design-conscious

### Best For
✅ HCI/Tech-focused positions  
✅ Design-forward programs  
✅ Modern research labs  
✅ Standing out from traditional CVs  
✅ Showing technical sophistication

### Key Features
- **🌓 Day/Night Mode Toggle** - Smooth theme switching
- Dark-first design optimized for extended viewing
- Sidebar navigation with always-visible profile
- Modern card-based layouts
- Gradient accents and subtle animations
- **Detailed project pages** - Comprehensive templates
- Keyboard shortcuts (Press 'T' to toggle theme)

### Pros
- Modern, eye-catching design
- Theme toggle shows technical ability
- Detailed project showcases
- Optimized for HCI audiences
- Mobile-friendly
- Memorable aesthetic

### Cons
- Less traditional
- Might not print as well
- More "opinionated" design

---

## Feature Comparison Table

| Feature | Professional Style | Modern Dark Style |
|---------|-------------------|-------------------|
| **Theme Toggle** | ❌ No | ✅ Yes (Dark/Light) |
| **Project Detail Pages** | ❌ No | ✅ Yes (Full templates) |
| **Sidebar Navigation** | ❌ No | ✅ Yes |
| **Timeline View** | ✅ Yes | ✅ Yes |
| **Publication Cards** | ✅ Yes | ✅ Yes |
| **Responsive Design** | ✅ Yes | ✅ Yes |
| **Animation Effects** | ⚠️ Basic | ✅ Advanced |
| **Skills Showcase** | ✅ Comprehensive | ✅ Modern Cards |
| **Traditional Feel** | ✅ High | ⚠️ Low |
| **Modern Tech Feel** | ⚠️ Low | ✅ High |
| **Print Friendly** | ✅ Yes | ⚠️ Medium |
| **Keyboard Shortcuts** | ❌ No | ✅ Yes |

---

## Recommendations by Program Type

### HCI / Tangible Interaction / Digital Fabrication
**→ Choose: Modern Dark Style (Option 2)**

Why:
- Shows technical sophistication
- Aligns with modern HCI aesthetics
- Demonstrates attention to design
- Theme toggle shows understanding of user preferences
- Detailed project pages showcase research depth

### Traditional Computer Science / Engineering
**→ Choose: Professional Style (Option 1)**

Why:
- Familiar academic format
- Content-first approach
- Comprehensive information display
- Less risky aesthetic
- Proven effective for traditional programs

### Architecture / Design Schools
**→ Choose: Modern Dark Style (Option 2)**

Why:
- Design-forward aesthetic
- Shows visual sensibility
- Project detail pages highlight design process
- Contemporary portfolio feel
- Aligns with design culture

### Mixed Applications (HCI + Traditional CS)
**→ Recommendation: Modern Dark Style (Option 2)**

Why:
- Best of both worlds
- Day mode provides traditional feel when needed
- Shows versatility
- More memorable
- Still professional in light mode

---

## Customization Difficulty

### Professional Style (Option 1)
**Difficulty**: ⭐⭐☆☆☆ (Easy)

- Simpler structure
- Fewer files
- Straightforward customization
- Less CSS complexity

### Modern Dark Style (Option 2)
**Difficulty**: ⭐⭐⭐☆☆ (Moderate)

- More files to manage
- Theme system requires understanding
- More CSS features
- Project pages need customization

Both are well-documented!

---

## Which Should You Choose?

### Choose Professional Style (Option 1) if:
- You want something quick to set up
- Applying to very traditional programs
- You prefer simpler customization
- You want maximum information density
- You're comfortable with conventional design

### Choose Modern Dark Style (Option 2) if:
- **Applying to HCI/Design programs** (your case!)
- You want to stand out
- You value modern aesthetics
- You want detailed project showcases
- You're comfortable with theme systems
- You want to show technical sophistication

---

## My Recommendation for Junke

**→ Go with Modern Dark Style (Option 2)**

### Reasons:
1. **Your Field**: HCI, Tangible Interaction, Digital Fabrication - these are design-forward fields
2. **Your Background**: CMU Computational Design + Architecture - shows design sensibility
3. **Your Research**: Transformable furniture needs visual showcase
4. **Differentiation**: Stands out in PhD application pools
5. **Future-Proof**: More impressive for modern research labs
6. **Project Detail**: Your transformable furniture research deserves dedicated pages

### How to Use Both:
You could actually use **BOTH**:
1. **Primary site**: Modern Dark Style (index-xiasu-style.html)
2. **Alternative**: Professional Style for conservative audiences
3. Link between them or choose based on program type

---

## Quick Start Guide

### For Professional Style:
1. Open `index.html`
2. Replace profile image
3. Update all personal info
4. Customize sections
5. Upload to GitHub Pages

### For Modern Dark Style:
1. Open `index-xiasu-style.html`
2. Replace profile image  
3. Update personal info in sidebar
4. Customize project cards
5. Edit project detail pages:
   - `project-transformable-furniture.html`
   - `project-taxonomy.html`
6. Test theme toggle
7. Upload to GitHub Pages

Both are ready to deploy! 🚀

---

## File Organization

### Keep Both Options:
```
my-website/
├── version-1-professional/
│   ├── index.html
│   ├── styles.css
│   └── script.js
│
├── version-2-modern/
│   ├── index-xiasu-style.html
│   ├── style.css
│   ├── project-style.css
│   ├── script-main.js
│   ├── project-transformable-furniture.html
│   └── project-taxonomy.html
│
└── assets/
    └── (shared images)
```

---

## Final Thoughts

Both websites are:
- ✅ Fully functional
- ✅ Responsive
- ✅ Well-documented
- ✅ Ready to deploy
- ✅ Customizable
- ✅ Professional

**The Modern Dark Style is more aligned with your HCI/Design focus**, but having both gives you flexibility!

Good luck with your PhD applications! 🎓
