# Visual Feature Guide - Academic Website Options

## 🎨 Style Overview

### Option 1: Professional Academic Style
```
┌─────────────────────────────────────────┐
│  Navigation Bar                          │
├─────────────────────────────────────────┤
│                                          │
│  ┌────────┐  Junke Zhao                 │
│  │ Photo  │  HCI Researcher              │
│  │        │  [Email] [CV] [Links]        │
│  └────────┘                              │
│                                          │
│  I am actively seeking PhD positions... │
│                                          │
├─────────────────────────────────────────┤
│  About Me                                │
│  ────────────────                        │
│  Research description...                 │
│  Research interests: [Tags]              │
│                                          │
│  [Highlight] [Highlight] [Highlight]    │
│                                          │
├─────────────────────────────────────────┤
│  Research Projects                       │
│  ─────────────────                       │
│  ┌────────┬────────┬────────┐           │
│  │Project │Project │Project │           │
│  │  1     │   2    │   3    │           │
│  └────────┴────────┴────────┘           │
│                                          │
├─────────────────────────────────────────┤
│  Publications                            │
│  ────────────                            │
│  • Paper Title 1                         │
│    Authors, Venue, Year                  │
│  • Paper Title 2                         │
│    Authors, Venue, Year                  │
│                                          │
├─────────────────────────────────────────┤
│  Experience & Education                  │
│  ──────────────────────                  │
│  Timeline view...                        │
│                                          │
└─────────────────────────────────────────┘

Colors: Light background, blue accents
Layout: Vertical scrolling, centered content
Width: Maximum 1200px
```

---

### Option 2: Modern Dark Style (Xia Su Inspired)
```
┌────────┬────────────────────────────────┐
│        │  [Theme Toggle ☀️/🌙]           │
│ SIDE   ├────────────────────────────────┤
│ BAR    │                                 │
│        │  About Me                       │
│ Photo  │  ─────────                      │
│        │  I'm a Research Assistant...    │
│ Name   │                                 │
│ Title  │  [Direction Card]               │
│        │  [Direction Card]               │
│ Email  │                                 │
│        │  ⚠️ I'm actively seeking PhD... │
│ Social │                                 │
│ Links  ├────────────────────────────────┤
│        │  Recent Experiences             │
│ Loc.   │  ──────────────────             │
│        │  ⚫→ Company 1                  │
│ [CV]   │     Details...                  │
│        │  ⚫→ Company 2                  │
│        │     Details...                  │
│        ├────────────────────────────────┤
│        │  Selected Publications          │
│        │  ─────────────────────          │
│        │  ┌────────┬────────┐           │
│        │  │Project │Project │           │
│        │  │ Card 1 │ Card 2 │           │
│        │  │[Image] │[Image] │           │
│        │  └────────┴────────┘           │
│        │  ┌────────┬────────┐           │
│        │  │Project │Project │           │
│        │  │ Card 3 │ Card 4 │           │
│        │  └────────┴────────┘           │
│        │                                 │
└────────┴────────────────────────────────┘

Colors: Dark background (#0a0a0a), blue accents (#4d9fff)
Layout: Fixed sidebar + scrolling content
Width: Sidebar 320px + Content max 1000px
```

---

## 🌓 Theme System (Option 2 Only)

### Dark Mode (Default)
```
Background:  #0a0a0a (Very dark gray)
Text:        #e8e8e8 (Light gray)
Cards:       #161616 (Dark gray)
Accent:      #4d9fff (Bright blue)
Borders:     #333333 (Medium gray)
```

### Light Mode (Toggle)
```
Background:  #ffffff (White)
Text:        #1a1a1a (Dark gray)
Cards:       #ffffff (White)
Accent:      #0066cc (Deep blue)
Borders:     #dee2e6 (Light gray)
```

**Toggle Button**: Fixed top-right corner
- Click or press 'T' key to switch
- Preference saved in localStorage
- Smooth 0.3s transition

---

## 📱 Responsive Behavior

### Desktop (> 1024px)
**Option 1:**
```
┌────────────────────────────────────┐
│     Full width content              │
│     Grid layouts: 2-3 columns       │
└────────────────────────────────────┘
```

**Option 2:**
```
┌──────┬───────────────────────────┐
│ Side │  Content Area             │
│ bar  │  Grid: 2-3 columns        │
└──────┴───────────────────────────┘
```

### Tablet (640-1024px)
**Both Options:**
```
┌────────────────────────────────────┐
│     Full width                      │
│     Grid layouts: 1-2 columns       │
│     Sidebar stacks on top (Opt. 2)  │
└────────────────────────────────────┘
```

### Mobile (< 640px)
**Both Options:**
```
┌────────────────┐
│  Single column │
│  Stacked       │
│  content       │
└────────────────┘
```

---

## 🎯 Interactive Features

### Option 1: Professional Style
- ✅ Smooth scrolling navigation
- ✅ Fade-in animations on scroll
- ✅ Hover effects on cards
- ✅ Active nav link highlighting
- ✅ Expandable sections
- ❌ No theme toggle
- ❌ No keyboard shortcuts

### Option 2: Modern Dark Style
- ✅ Everything in Option 1, PLUS:
- ✅ **Theme toggle** (click or press 'T')
- ✅ Advanced hover animations
- ✅ Tooltips on hover
- ✅ Smooth theme transitions
- ✅ LocalStorage persistence
- ✅ Keyboard shortcuts
- ✅ Sidebar auto-hide on mobile scroll

---

## 📄 Page Structure Comparison

### Option 1 Pages
```
Main Site
└── index.html (All content in one page)
    ├── Hero
    ├── About
    ├── Research
    ├── Publications
    ├── Experience
    ├── Skills
    └── Contact
```

### Option 2 Pages
```
Main Site
├── index-xiasu-style.html (Homepage)
│   ├── About
│   ├── Experience
│   ├── Education
│   ├── Publications Grid
│   └── Skills
│
├── project-transformable-furniture.html
│   ├── Header
│   ├── Abstract
│   ├── Features
│   ├── Methodology
│   ├── Taxonomy
│   ├── Visualizations
│   ├── Findings
│   └── Future Work
│
└── project-taxonomy.html
    ├── Header
    ├── Research Questions
    ├── Methodology
    ├── Literature Overview
    ├── Framework
    └── Applications
```

---

## 🎨 Component Showcase

### Publication Cards (Both Options)

**Option 1:**
```
┌─────────────────────────────────┐
│ Year  Title                      │
│       Authors                    │
│       Venue                      │
│       Description...             │
│       [Status Badge]             │
└─────────────────────────────────┘
```

**Option 2:**
```
┌──────────────────┐
│                  │
│  [Project Image] │
│                  │
├──────────────────┤
│ Title            │
│ Venue            │
│ Description...   │
└──────────────────┘
↑ Hover: Lift effect, border glow
↑ Click: Opens detail page
```

---

### Timeline (Both Options)

**Option 1:**
```
────○─── Year
     │   Position
     │   Company
     │   Description
     │
────○─── Year
     │   Position
     │   Company
     │   Description
```

**Option 2:**
```
⚫──┬─── [Logo]
   │    Company Name
   │    Position. Date
   │
⚫──┬─── [Logo]
   │    Company Name
   │    Position. Date
```

---

## 🚀 Performance

### Load Times (Estimated)

**Option 1:**
- HTML: ~20KB
- CSS: ~13KB
- JS: ~6KB
- **Total: ~39KB** (before images)
- **Load time: < 1 second**

**Option 2:**
- HTML (all pages): ~60KB
- CSS (both files): ~25KB
- JS: ~5KB
- **Total: ~90KB** (before images)
- **Load time: < 1.5 seconds**

Both are lightweight and fast!

---

## 🎓 Academic Credibility

### Traditional Indicators (Both Options)
- ✅ Publication list
- ✅ Institution affiliation
- ✅ CV download
- ✅ Research interests
- ✅ Experience timeline
- ✅ Contact information

### Modern Indicators (Option 2 Adds)
- ✅ Detailed project pages
- ✅ Technical sophistication (theme system)
- ✅ Design sensibility
- ✅ Portfolio-quality presentation
- ✅ Interactive elements

---

## 💡 Quick Visual Comparison

```
OPTION 1: Professional          OPTION 2: Modern Dark
════════════════════            ════════════════════

Traditional ✓✓✓✓✓              Modern    ✓✓✓✓✓
Modern      ✓✓                  Traditional ✓✓✓

Simple      ✓✓✓✓✓              Complex    ✓✓✓
Complex     ✓✓                  Simple     ✓✓

Safe        ✓✓✓✓✓              Bold       ✓✓✓✓
Bold        ✓✓                  Safe       ✓✓✓

Versatile   ✓✓✓✓               Specialized ✓✓✓✓✓
```

---

## 🎯 Best For Visual Summary

### Option 1: Professional Style
```
👨‍🎓 Traditional Academia
📄 Text-Heavy CVs
🔬 Conservative Programs
📊 Data/Publications Focus
⚡ Quick Setup
```

### Option 2: Modern Dark Style
```
💻 HCI/Design Programs
🎨 Visual Projects
🚀 Tech-Forward Labs
📱 Modern Aesthetics
⚙️ Technical Sophistication
```

---

## 📐 Layout Measurements

### Option 1: Professional Style
- Max width: 1200px
- Padding: 60px vertical
- Section gap: 80px
- Card gap: 25-30px
- Font sizes: 16-40px

### Option 2: Modern Dark Style
- Sidebar: 320px fixed
- Content max: 1000px
- Padding: 60-80px
- Section gap: 80px
- Card gap: 25px
- Font sizes: 14-45px

---

## 🎨 Color Palette Details

### Option 1 Colors
```css
Primary:    #2c3e50 (Dark blue-gray)
Secondary:  #3498db (Bright blue)
Accent:     #e74c3c (Red)
Background: #f8f9fa (Light gray)
Text:       #333333 (Dark gray)
```

### Option 2 Colors (Dark Mode)
```css
Primary:    #0a0a0a (True black)
Secondary:  #1a1a1a (Dark gray)
Accent:     #4d9fff (Bright blue)
Text:       #e8e8e8 (Light gray)
Border:     #333333 (Medium gray)
```

### Option 2 Colors (Light Mode)
```css
Primary:    #ffffff (White)
Secondary:  #f8f9fa (Off-white)
Accent:     #0066cc (Deep blue)
Text:       #1a1a1a (Dark gray)
Border:     #dee2e6 (Light gray)
```

---

**This guide helps visualize the differences between the two options.**  
**Choose based on your target audience and personal preference!**

📖 Next: Read `COMPARISON-GUIDE.md` for detailed recommendations
