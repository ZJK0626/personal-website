# Academic Personal Website - Complete Package for Junke Zhao

Welcome! You now have **TWO complete professional academic websites** to choose from, each designed for different audiences and purposes.

## 📦 What's Included

### ✨ Option 1: Professional Academic Style
A traditional, comprehensive academic website perfect for general PhD applications.

**Files:**
- `index.html` - Main homepage
- `styles.css` - Complete stylesheet
- `script.js` - Interactive features
- `README.md` - Setup instructions
- `alternative-minimalist.html` - Bonus minimalist version

**Best for:** Traditional academic programs, comprehensive portfolios

---

### 🌓 Option 2: Modern Dark Style (Xia Su Inspired)
A sleek, modern website with day/night mode toggle and detailed project pages, inspired by leading HCI researchers.

**Files:**
- `index-xiasu-style.html` - Main homepage with sidebar
- `style.css` - Theme system stylesheet
- `project-style.css` - Project page stylesheet
- `script-main.js` - Theme toggle and interactions
- `project-transformable-furniture.html` - Detailed project page 1
- `project-taxonomy.html` - Detailed project page 2
- `README-xiasu-style.md` - Complete setup guide

**Best for:** HCI programs, design-forward positions, modern research labs

---

## 🎯 Quick Decision Guide

**Are you applying to HCI, Tangible Interaction, or Digital Fabrication programs?**
→ **Choose Option 2 (Modern Dark Style)**

**Are you applying to traditional CS or Engineering programs?**
→ **Choose Option 1 (Professional Style)**

**Not sure?**
→ **Go with Option 2** - It's more versatile and memorable while still professional

---

## 🚀 Getting Started

### Step 1: Choose Your Style
Read `COMPARISON-GUIDE.md` for detailed comparison

### Step 2: Prepare Your Content
- Professional headshot photo
- Research project images
- CV/Resume PDF
- Publication details
- Experience information

### Step 3: Customize
Follow the README for your chosen style:
- Option 1: See `README.md`
- Option 2: See `README-xiasu-style.md`

### Step 4: Deploy
Both support:
- GitHub Pages (recommended, free)
- Netlify (easy drag-and-drop)
- Vercel (fast deployment)

---

## 📚 Documentation

| Document | Description |
|----------|-------------|
| `COMPARISON-GUIDE.md` | **START HERE** - Compare both options |
| `README.md` | Professional Style setup guide |
| `README-xiasu-style.md` | Modern Dark Style setup guide |

---

## 🎨 Key Features by Option

### Professional Style Features
✅ Clean, traditional academic design  
✅ Comprehensive information layout  
✅ Publication-focused sections  
✅ Timeline-based experience  
✅ Skills showcase  
✅ Mobile responsive  
✅ Easy to customize  

### Modern Dark Style Features
✅ Everything in Professional Style, PLUS:  
✅ **Day/Night mode toggle** with localStorage  
✅ Dark-optimized design  
✅ **Detailed project page templates**  
✅ Sidebar navigation with profile  
✅ Modern card-based layouts  
✅ Advanced animations  
✅ Keyboard shortcuts (Press 'T')  
✅ Theme system with CSS variables  

---

## 📁 Recommended File Organization

```
my-academic-website/
├── index.html                    # Your chosen homepage
├── *.css                         # Required stylesheets
├── *.js                          # Required scripts
├── project-*.html                # If using Option 2
├── assets/                       # Create this folder
│   ├── profile.jpg
│   ├── project-*.jpg
│   └── cv.pdf
└── README.md                     # Your chosen README
```

---

## 💡 Recommendations

### For Your Specific Case (Junke Zhao)

**Best Choice: Modern Dark Style (Option 2)**

Why:
1. **Your field is HCI** - This design shows you understand modern interface design
2. **Your research is visual** - Transformable furniture needs project showcase pages
3. **Your background** - CMU Computational Design shows design sensibility
4. **Differentiation** - Stands out in competitive PhD applications
5. **Technical sophistication** - Theme toggle demonstrates technical ability

### How to Use Both
You can actually maintain both:
- **Primary site**: Modern Dark Style (for HCI programs)
- **Alternative**: Professional Style (for traditional programs)
- Host different versions on subdomains or paths

---

## 🎓 PhD Application Tips

### What Committees Look For
- Clear research interests ✅ Both styles provide this
- Publication record ✅ Both styles showcase this
- Technical skills ✅ Both styles display this
- Design sensibility ✅ Option 2 excels here
- Attention to detail ✅ Both demonstrate this
- Modern tools knowledge ✅ Option 2 highlights this

### Making Your Choice
- **Conservative programs**: Either works, Option 1 is safer
- **HCI/Design programs**: Option 2 is strongly recommended
- **Top-tier tech labs**: Option 2 aligns with their aesthetic
- **Mixed applications**: Option 2 with light mode for conservative programs

---

## 🛠️ Customization Difficulty

### Option 1 (Professional Style)
**Time to customize**: 2-3 hours  
**Technical difficulty**: Easy ⭐⭐☆☆☆  
**Files to edit**: 3 main files  

### Option 2 (Modern Dark Style)
**Time to customize**: 4-6 hours  
**Technical difficulty**: Moderate ⭐⭐⭐☆☆  
**Files to edit**: 6+ files including project pages  

Both include comprehensive documentation!

---

## 📱 What Works on Mobile

Both options are fully responsive:
- ✅ Adaptive layouts
- ✅ Touch-friendly navigation
- ✅ Readable on small screens
- ✅ Fast loading
- ✅ No horizontal scrolling

---

## 🌐 Deployment Checklist

Before going live:
- [ ] Updated all personal information
- [ ] Added all images
- [ ] Tested on multiple browsers
- [ ] Tested on mobile devices
- [ ] Checked all links work
- [ ] Added your CV/Resume
- [ ] Tested theme toggle (if Option 2)
- [ ] Verified contact information
- [ ] Spell-checked all content
- [ ] Asked friend to review

---

## 🎨 Image Requirements

### Required for Both Options
- **profile.jpg** - 150x150px minimum, square
- **cv.pdf** - Your current CV/Resume

### Additional for Option 2
- **project-furniture.jpg** - 800x600px recommended
- **project-taxonomy.jpg** - 800x600px recommended
- **project-viz.jpg** - 800x600px recommended
- **project-cmu.jpg** - 800x600px recommended

Use compressed images (TinyPNG recommended)

---

## 🔧 Technical Support

### If Something Doesn't Work
1. Check the README for your chosen style
2. Look at code comments
3. Test in incognito/private mode
4. Check browser console for errors
5. Verify all files are in correct locations

### Common Issues
- **Images not loading**: Check file paths match exactly
- **Theme not switching**: Clear browser cache and localStorage
- **Layout broken on mobile**: Test on actual device, not just resize
- **Links not working**: Verify file names match links exactly

---

## 📊 Success Metrics

After deployment, track:
- Visitor analytics (Google Analytics)
- Load speed (PageSpeed Insights)
- Mobile usability (Mobile-Friendly Test)
- Accessibility (WAVE Tool)

---

## 🎯 Next Steps

1. **Read** `COMPARISON-GUIDE.md` carefully
2. **Choose** your preferred style
3. **Read** the specific README for that style
4. **Gather** your content (photos, CV, project info)
5. **Customize** following the README instructions
6. **Test** thoroughly on multiple devices
7. **Deploy** to GitHub Pages or Netlify
8. **Share** with your network!

---

## 💪 You've Got This!

Both websites are:
- ✅ Production-ready
- ✅ Well-documented  
- ✅ Professional quality
- ✅ Tested and functional
- ✅ Optimized for your field

Choose the one that feels right for your applications, customize it with your content, and you'll have a website that helps you stand out in PhD applications!

---

## 📬 Contact & Links

Update these in your chosen website:
- Email: junke.zhao@utdallas.edu
- Location: Dallas, Texas, USA
- Affiliation: University of Texas at Dallas

---

**Package Created**: November 2024  
**Created For**: Junke Zhao  
**Purpose**: PhD Applications in HCI, Tangible Interaction, Digital Fabrication  

🚀 **Good luck with your PhD applications!** 🎓
