# Academic Personal Website - Xia Su Style with Day/Night Mode

A modern, dark-themed academic website inspired by Xia Su's personal page, featuring smooth day/night mode toggle and detailed project page templates.

## ✨ Features

### Core Features
- **🌓 Day/Night Mode Toggle**: Smooth theme switching with localStorage persistence
- **🎨 Dark-First Design**: Beautiful dark mode optimized for extended viewing
- **📱 Fully Responsive**: Perfect on desktop, tablet, and mobile devices
- **⚡ Smooth Animations**: Fade-in effects and hover interactions
- **🎯 Project Detail Pages**: Comprehensive templates for showcasing research

### Design Highlights
- Sidebar navigation with profile section
- Clean, minimalist typography
- Gradient accents and modern color scheme
- Interactive publication cards
- Timeline-based experience section
- Comprehensive project showcase
- Keyboard shortcuts (Press 'T' to toggle theme)

## 📁 File Structure

```
website/
├── index-xiasu-style.html           # Main homepage
├── style.css                         # Main stylesheet with theme variables
├── project-style.css                 # Project detail page styles
├── script-main.js                    # Theme toggle and interactions
├── project-transformable-furniture.html  # Detailed project page 1
├── project-taxonomy.html             # Detailed project page 2
├── README-xiasu-style.md            # This file
└── assets/                          # Create this folder
    ├── profile.jpg
    ├── project-furniture.jpg
    ├── project-taxonomy.jpg
    ├── project-viz.jpg
    ├── project-cmu.jpg
    └── ... (other images)
```

## 🚀 Quick Start

### 1. Setup Files

1. Download all HTML, CSS, and JS files
2. Create an `assets` folder for images
3. Add your images (see Image Requirements below)

### 2. Customize Content

#### Update Personal Information (index-xiasu-style.html)

**Profile Section (Lines ~25-60):**
```html
<h1>Your Name</h1>
<p class="role">Your Title</p>
<a href="mailto:your.email@domain.com">
```

**About Section (Lines ~80-120):**
- Update research description
- Modify research directions
- Edit status banner

**Experience & Education:**
- Update timeline items
- Modify company/university names
- Adjust dates and positions

#### Update Projects

**Main Page (Lines ~150-220):**
- Update project cards
- Link to detail pages
- Add project images

**Detail Pages:**
- Customize project-transformable-furniture.html
- Customize project-taxonomy.html
- Create additional pages as needed

### 3. Customize Colors

Edit CSS variables in `style.css` (Lines 1-30):

```css
:root[data-theme="dark"] {
    --bg-primary: #0a0a0a;          /* Main background */
    --accent-color: #4d9fff;         /* Primary accent */
    --text-primary: #e8e8e8;         /* Main text */
    /* ... other variables ... */
}

:root[data-theme="light"] {
    --bg-primary: #ffffff;
    --accent-color: #0066cc;
    --text-primary: #1a1a1a;
    /* ... other variables ... */
}
```

## 📸 Image Requirements

### Required Images

1. **profile.jpg** (150x150px, round)
   - Professional headshot
   - High quality, well-lit
   - Neutral background

2. **Project Images** (recommended 800x600px):
   - project-furniture.jpg
   - project-taxonomy.jpg
   - project-viz.jpg
   - project-cmu.jpg

3. **Project Detail Images**:
   - taxonomy-diagram.jpg
   - sankey-diagram.jpg
   - network-graph.jpg
   - matrix-view.jpg

### Image Optimization
- Use compressed JPG/PNG formats
- Recommended max file size: 500KB
- Use tools like TinyPNG for compression

## 🎨 Theme System

### How It Works

The theme system uses CSS variables and localStorage:

1. **Default**: Dark mode
2. **Toggle**: Click theme button or press 'T'
3. **Persistence**: Choice saved in localStorage
4. **Smooth Transition**: All elements animate on theme change

### Keyboard Shortcuts

- `T` - Toggle between dark and light modes
- Works anywhere except in input fields

## 📱 Responsive Breakpoints

```css
Desktop:   > 1024px  (Sidebar + Content grid)
Tablet:    640-1024px (Stacked layout)
Mobile:    < 640px   (Single column)
```

## 🔧 Customization Guide

### Adding a New Project Page

1. **Duplicate Template:**
```bash
cp project-transformable-furniture.html project-new.html
```

2. **Update Content:**
- Change title and metadata
- Update abstract and sections
- Add project-specific images

3. **Link from Homepage:**
```html
<a href="project-new.html" class="publication-card">
    <!-- Card content -->
</a>
```

### Adding a New Section

```html
<section id="newsection" class="section">
    <h2 class="section-title">New Section</h2>
    <!-- Your content -->
</section>
```

### Customizing Timeline

```html
<div class="timeline-item">
    <div class="timeline-icon">
        <i class="fas fa-icon-name"></i>
    </div>
    <div class="timeline-content">
        <div class="company-logo">LOGO</div>
        <h3>Position Title</h3>
        <p class="position">Details. Date range</p>
    </div>
</div>
```

## 🎯 Project Page Components

### Available Sections

All project pages support these components:

1. **Project Header**
   - Title, subtitle, metadata
   - Author list
   - External links (demo, GitHub, paper)

2. **Abstract**
   - Research overview
   - Key contributions

3. **Features Grid**
   - Key capabilities
   - Icon + description cards

4. **Methodology Steps**
   - Numbered process steps
   - Research approach

5. **Visualizations**
   - Image showcases
   - Interactive demos

6. **Findings & Results**
   - Key insights
   - Data points

7. **Impact & Applications**
   - Use cases
   - Target audiences

8. **Future Work**
   - Planned extensions
   - Research directions

## 🌐 Deployment Options

### Option 1: GitHub Pages (Recommended)

1. Create repository: `yourusername.github.io`
2. Push all files
3. Enable GitHub Pages in Settings
4. Access at `https://yourusername.github.io`

### Option 2: Netlify

1. Sign up at netlify.com
2. Drag & drop folder
3. Get instant deployment
4. Optional: Add custom domain

### Option 3: Vercel

1. Install Vercel CLI: `npm i -g vercel`
2. Run `vercel` in project folder
3. Follow prompts
4. Get deployment URL

## 🎨 Design Philosophy

This template follows Xia Su's design principles:

1. **Dark-First**: Optimized for dark mode viewing
2. **Minimalist**: Clean lines, generous whitespace
3. **Typography-Focused**: Clear hierarchy, readable fonts
4. **Subtle Animations**: Smooth, non-distracting
5. **Content-First**: Research and projects take center stage
6. **Professional**: Academic credibility with modern aesthetics

## 🔍 SEO Optimization

### Update Meta Tags

```html
<title>Your Name | Research Field</title>
<meta name="description" content="Brief research description">
<meta name="keywords" content="HCI, research areas, expertise">
<meta name="author" content="Your Name">
```

### Add Structured Data

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Person",
  "name": "Your Name",
  "jobTitle": "PhD Student",
  "affiliation": "University Name"
}
</script>
```

## 🐛 Troubleshooting

### Theme Not Switching
- Check JavaScript console for errors
- Verify script-main.js is loaded
- Clear browser cache and localStorage

### Images Not Loading
- Check file paths match exactly
- Verify images exist in assets folder
- Check browser console for 404 errors

### Layout Issues on Mobile
- Test on actual devices, not just browser resize
- Check CSS media queries
- Verify viewport meta tag exists

### Animations Not Working
- Ensure IntersectionObserver is supported
- Check for JavaScript errors
- Verify CSS transitions are enabled

## 📝 Best Practices

### Content
- ✅ Keep descriptions concise but informative
- ✅ Use active voice
- ✅ Highlight key contributions
- ✅ Include concrete examples
- ❌ Avoid jargon without explanation
- ❌ Don't over-sell research

### Images
- ✅ Use consistent aspect ratios
- ✅ Compress all images
- ✅ Add descriptive alt text
- ✅ Use modern formats (WebP when possible)
- ❌ Don't use stock photos
- ❌ Avoid low-quality images

### Performance
- ✅ Minimize HTTP requests
- ✅ Use CDN for libraries
- ✅ Compress CSS/JS
- ✅ Lazy load images
- ❌ Don't load unnecessary resources
- ❌ Avoid inline styles

## 🔄 Updates & Maintenance

### Regular Updates
- **Weekly**: Check for broken links
- **Monthly**: Update publications/news
- **Quarterly**: Review all content
- **Annually**: Refresh design if needed

### Version Control
Use Git to track changes:
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin your-repo-url
git push -u origin main
```

## 📚 Resources

### Icons
- [Font Awesome](https://fontawesome.com/) - Icon library used

### Fonts
- System fonts for optimal performance
- `-apple-system, BlinkMacSystemFont, 'Segoe UI'`

### Color Tools
- [Coolors](https://coolors.co/) - Color palette generator
- [Contrast Checker](https://webaim.org/resources/contrastchecker/)

### Image Tools
- [TinyPNG](https://tinypng.com/) - Image compression
- [Squoosh](https://squoosh.app/) - Image optimizer

## 💡 Tips for Success

1. **Keep It Updated**: Regular updates show active research
2. **High-Quality Images**: First impressions matter
3. **Mobile-First**: Many visitors use phones
4. **Fast Loading**: Optimize everything
5. **Clear Navigation**: Make information easy to find
6. **Accessibility**: Use semantic HTML and ARIA labels
7. **Professional Tone**: But still personable
8. **Showcase Best Work**: Quality over quantity

## 🤝 Support

For issues or questions:
1. Check this README first
2. Review code comments
3. Test in incognito mode
4. Check browser console

## 📄 License

This template is provided for personal academic use. Customize and use freely for your academic website.

---

**Created for**: Junke Zhao  
**Inspired by**: Xia Su's personal website  
**Last Updated**: November 2024  
**Version**: 1.0

Good luck with your academic website! 🚀
